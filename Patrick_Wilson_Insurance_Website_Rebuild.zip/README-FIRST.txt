PATRICK WILSON INSURANCE PROFESSIONALS — WEBSITE REBUILD

Upload the contents of this folder to the root of the existing GitHub Pages repository, preserving the assets folder.

The quote and appointment forms create a text-message draft to Patrick at 479-305-3739. The visitor must review and send the text. This website does not store or automatically transmit form entries.

Do not collect Social Security numbers, payment data, policy documents, or other sensitive information through these forms. Customer login and document upload are not implemented; add them only after selecting an insurer-approved secure portal/backend and obtaining its official URL.
